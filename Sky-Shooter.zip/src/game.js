// Sky Shooter - Core bootstrap: canvas, loop, input, basic player & HUD wiring

// ---------- DOM References ----------
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const hudEl = document.getElementById('hud');
const scoreEl = document.getElementById('score');
const highScoreEl = document.getElementById('highScore');
const levelEl = document.getElementById('level');
const livesEl = document.getElementById('lives');
const healthFillEl = document.getElementById('healthFill');

const menuStartEl = document.getElementById('menu-start');
const menuPauseEl = document.getElementById('menu-pause');
const menuGameOverEl = document.getElementById('menu-gameover');

const btnStart = document.getElementById('btnStart');
const playerNameInput = document.getElementById('playerName');
const leaderboardEl = document.getElementById('leaderboard');

const btnResume = document.getElementById('btnResume');
const btnRestart = document.getElementById('btnRestart');

const btnPlayAgain = document.getElementById('btnPlayAgain');
const btnHome = document.getElementById('btnHome');
const finalScoreEl = document.getElementById('finalScore');
const achievementsUnlockedEl = document.getElementById('achievementsUnlocked');

// ---------- Canvas & Resolution ----------
let deviceScale = 1;
function computeScale() {
  // Recompute DPR on each resize for mobile zoom/rotate correctness
  deviceScale = Math.min(window.devicePixelRatio || 1, 2);
}
function resizeCanvas() {
  computeScale();
  const width = Math.max(320, Math.floor(window.innerWidth));
  const height = Math.max(480, Math.floor(window.innerHeight));
  canvas.width = Math.floor(width * deviceScale);
  canvas.height = Math.floor(height * deviceScale);
  canvas.style.width = width + 'px';
  canvas.style.height = height + 'px';
  ctx.setTransform(deviceScale, 0, 0, deviceScale, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// ---------- Local Storage Helpers ----------
const STORAGE_KEYS = {
  playerName: 'skyshooter:playerName',
  highScore: 'skyshooter:highScore',
  leaderboard: 'skyshooter:leaderboard',
  achievements: 'skyshooter:achievements',
  save: 'skyshooter:save',
};

function getPlayerName() {
  return localStorage.getItem(STORAGE_KEYS.playerName) || '';
}
function setPlayerName(name) {
  localStorage.setItem(STORAGE_KEYS.playerName, name);
}
function getHighScore() {
  return Number(localStorage.getItem(STORAGE_KEYS.highScore) || 0);
}
function setHighScore(score) {
  localStorage.setItem(STORAGE_KEYS.highScore, String(score));
}
function getLeaderboard() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.leaderboard);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}
function setLeaderboard(list) {
  localStorage.setItem(STORAGE_KEYS.leaderboard, JSON.stringify(list));
}

function getAchievements() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.achievements);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}
function setAchievements(obj) {
  localStorage.setItem(STORAGE_KEYS.achievements, JSON.stringify(obj));
}

// Persistent save (JSON stored in localStorage)
function getSave() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.save);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}
function setSave(saveObj) {
  localStorage.setItem(STORAGE_KEYS.save, JSON.stringify(saveObj));
}

// ---------- Leaderboard UI ----------
function renderLeaderboard() {
  const list = getLeaderboard();
  const top = list.slice(0, 10);
  leaderboardEl.innerHTML = '<h3>Top Scores</h3>' +
    (top.length === 0
      ? '<div class="lb-row">No scores yet. Be the first!</div>'
      : top
          .map((e, i) => `<div class="lb-row"><span>${i + 1}. ${e.name || 'Player'}</span><span>${e.score}</span></div>`) 
          .join(''));
}

// ---------- Input Handling ----------
const keysDown = new Set();
let shootRequested = false;

window.addEventListener('keydown', (e) => {
  if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) {
    e.preventDefault();
  }
  keysDown.add(e.key.toLowerCase());
  if (e.key === ' ') shootRequested = true;
  if (e.key.toLowerCase() === 'p') togglePause();
});
window.addEventListener('keyup', (e) => {
  keysDown.delete(e.key.toLowerCase());
});

// Basic touch controls: drag to move, tap to shoot
let isTouching = false;
let lastTouch = null;
canvas.addEventListener('touchstart', (e) => {
  isTouching = true;
  lastTouch = e.touches[0];
  shootRequested = true;
});
canvas.addEventListener('touchmove', (e) => {
  lastTouch = e.touches[0];
});
canvas.addEventListener('touchend', () => {
  isTouching = false;
  lastTouch = null;
});

// ---------- Game State ----------
const GameState = {
  Menu: 'menu',
  Playing: 'playing',
  Paused: 'paused',
  GameOver: 'gameover',
};

const player = {
  x: 0,
  y: 0,
  width: 42,
  height: 48,
  speed: 320,
  vx: 0,
  vy: 0,
  maxHealth: 100,
  health: 100,
  lives: 3,
  fireCooldownMs: 140,
  lastFireAt: 0,
  hasShield: false,
  shieldUntil: 0,
  doubleFireUntil: 0,
  speedBoostUntil: 0,
};

const bullets = [];
const enemies = [];
const particles = [];
const powerups = [];
let boss = null;

const world = {
  state: GameState.Menu,
  score: 0,
  level: 1,
  bgTime: 0,
  sessionAchievements: {},
};

function resetPlayerPosition() {
  player.x = canvas.width / deviceScale / 2 - player.width / 2;
  player.y = canvas.height / deviceScale - player.height - 30;
}

function resetGame() {
  const saved = getSave();
  world.score = typeof saved.score === 'number' ? saved.score : 0;
  world.level = 1;
  world.bgTime = 0;
  world.sessionAchievements = {};
  player.health = player.maxHealth;
  player.lives = 3;
  player.vx = 0;
  player.vy = 0;
  bullets.length = 0;
  enemies.length = 0;
  particles.length = 0;
  powerups.length = 0;
  boss = null;
  resetPlayerPosition();
  updateHUD();
}

// ---------- HUD / UI ----------
function updateHUD() {
  scoreEl.textContent = String(world.score);
  highScoreEl.textContent = String(getHighScore());
  levelEl.textContent = `Level ${world.level}`;
  // Lives
  livesEl.innerHTML = '';
  for (let i = 0; i < player.lives; i++) {
    const life = document.createElement('div');
    life.className = 'life';
    livesEl.appendChild(life);
  }
  // Health
  const pct = Math.max(0, Math.min(1, player.health / player.maxHealth));
  healthFillEl.style.width = `${Math.round(pct * 100)}%`;
}

function showMenu(menu) {
  menuStartEl.classList.add('hidden');
  menuPauseEl.classList.add('hidden');
  menuGameOverEl.classList.add('hidden');
  if (menu) menu.classList.remove('hidden');
}
function showHUD(show) {
  if (show) {
    hudEl.classList.remove('hidden');
    hudEl.classList.add('overlay');
  } else {
    hudEl.classList.add('hidden');
  }
}

function startGame() {
  const name = (playerNameInput.value || 'Player').trim().slice(0, 12);
  setPlayerName(name);
  world.state = GameState.Playing;
  resetGame();
  showMenu(null);
  showHUD(true);
}

function togglePause() {
  if (world.state === GameState.Playing) {
    world.state = GameState.Paused;
    showMenu(menuPauseEl);
  } else if (world.state === GameState.Paused) {
    world.state = GameState.Playing;
    showMenu(null);
  }
}

function gameOver() {
  world.state = GameState.GameOver;
  showHUD(false);
  showMenu(menuGameOverEl);
  finalScoreEl.textContent = String(world.score);
  // Update high score
  const prev = getHighScore();
  if (world.score > prev) setHighScore(world.score);
  // Update leaderboard
  const list = getLeaderboard();
  list.push({ name: getPlayerName() || 'Player', score: world.score, at: Date.now() });
  list.sort((a, b) => b.score - a.score);
  setLeaderboard(list.slice(0, 10));
  renderLeaderboard();
  // Show session achievements
  achievementsUnlockedEl.innerHTML = renderSessionAchievements();
}

// ---------- Entities: Bullets ----------
function tryShoot(now) {
  if (now - player.lastFireAt < player.fireCooldownMs) return;
  player.lastFireAt = now;
  const doubleFireActive = now < player.doubleFireUntil;
  if (doubleFireActive) {
    const offset = 10;
    bullets.push({ x: player.x + player.width / 2 - 3 - offset, y: player.y - 8, width: 6, height: 12, vy: -600 });
    bullets.push({ x: player.x + player.width / 2 - 3 + offset, y: player.y - 8, width: 6, height: 12, vy: -600 });
  } else {
    bullets.push({ x: player.x + player.width / 2 - 3, y: player.y - 8, width: 6, height: 12, vy: -600 });
  }
}

function updateBullets(dt) {
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    b.y += b.vy * dt;
    if (b.y + b.height < -20) bullets.splice(i, 1);
  }
}

function drawBullets() {
  for (const b of bullets) {
    // Glow bullet
    const grd = ctx.createLinearGradient(b.x, b.y, b.x, b.y + b.height);
    grd.addColorStop(0, 'rgba(93,242,255,0.95)');
    grd.addColorStop(1, 'rgba(138,93,255,0.85)');
    ctx.fillStyle = grd;
    ctx.shadowColor = 'rgba(93,242,255,0.6)';
    ctx.shadowBlur = 12;
    ctx.fillRect(b.x, b.y, b.width, b.height);
    ctx.shadowBlur = 0;
  }
}

// ---------- Particles (simple explosion sparks) ----------
function spawnExplosion(x, y, color = 'rgba(255,200,120,1)', count = 16) {
  for (let i = 0; i < count; i++) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 80 + Math.random() * 220;
    particles.push({
      x, y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 0.5 + Math.random() * 0.5,
      color,
      size: 2 + Math.random() * 2,
    });
  }
}
function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life -= dt;
    if (p.life <= 0) { particles.splice(i, 1); continue; }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.98; p.vy *= 0.98;
  }
}
function drawParticles() {
  for (const p of particles) {
    const alpha = Math.max(0, Math.min(1, p.life));
    ctx.fillStyle = p.color.replace(',1)', `,${alpha})`);
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
}

// ---------- Enemies & Waves ----------
let spawnTimer = 0;
let waveTimer = 0;
let waveIndex = 0;

function enemyTemplate(type) {
  // type: 0 basic, 1 fast, 2 tanky
  if (type === 1) return { width: 34, height: 34, speed: 180, hp: 1, score: 30, colorA: 'rgba(255,120,170,0.85)', colorB: 'rgba(255,200,230,0.85)' };
  if (type === 2) return { width: 48, height: 50, speed: 90, hp: 3, score: 80, colorA: 'rgba(255,190,120,0.9)', colorB: 'rgba(255,240,200,0.9)' };
  return { width: 36, height: 38, speed: 120, hp: 2, score: 50, colorA: 'rgba(120,200,255,0.9)', colorB: 'rgba(200,240,255,0.9)' };
}

function spawnEnemyRow(count, type) {
  const w = canvas.width / deviceScale;
  const tpl = enemyTemplate(type);
  const gap = Math.max(40, (w - 80) / (count + 1));
  for (let i = 0; i < count; i++) {
    enemies.push({
      x: 40 + gap * (i + 1) - tpl.width / 2,
      y: -tpl.height - Math.random() * 120,
      width: tpl.width,
      height: tpl.height,
      vy: tpl.speed,
      hp: tpl.hp,
      score: tpl.score,
      colorA: tpl.colorA,
      colorB: tpl.colorB,
      wobbleT: Math.random() * Math.PI * 2,
    });
  }
}

function updateWaves(dt) {
  if (world.state !== GameState.Playing) return;
  waveTimer += dt;
  spawnTimer += dt;
  const levelFactor = 1 + (world.level - 1) * 0.12;
  const spawnInterval = Math.max(0.6, 1.3 / levelFactor);

  if (spawnTimer >= spawnInterval) {
    spawnTimer = 0;
    const type = (waveIndex % 5 === 4) ? 2 : (Math.random() < 0.4 ? 1 : 0);
    const count = 3 + Math.floor(Math.random() * Math.min(4 + world.level, 6));
    spawnEnemyRow(count, type);
    waveIndex++;
  }

  // Level progression by time
  if (waveTimer >= 30) {
    waveTimer = 0;
    world.level++;
    updateHUD();
  }
}

function updateEnemies(dt) {
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;
  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    e.wobbleT += dt * 2;
    e.x += Math.sin(e.wobbleT) * 20 * dt;
    e.y += e.vy * dt;
    if (e.y > h + 60) {
      enemies.splice(i, 1);
    }
  }
}

function drawEnemies() {
  for (const e of enemies) {
    const grad = ctx.createLinearGradient(e.x, e.y, e.x, e.y + e.height);
    grad.addColorStop(0, e.colorA);
    grad.addColorStop(1, e.colorB);
    ctx.fillStyle = grad;
    ctx.shadowColor = e.colorA.replace('0.9', '0.5').replace('0.85', '0.45');
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.moveTo(e.x + e.width / 2, e.y);
    ctx.lineTo(e.x + e.width, e.y + e.height * 0.7);
    ctx.lineTo(e.x + e.width * 0.7, e.y + e.height);
    ctx.lineTo(e.x + e.width * 0.3, e.y + e.height);
    ctx.lineTo(e.x, e.y + e.height * 0.7);
    ctx.closePath();
    ctx.fill();
    ctx.shadowBlur = 0;
  }
}

// ---------- Collisions ----------
function rectsOverlap(a, b) {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

function handleCollisions() {
  // Bullets -> Enemies
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    let hit = false;
    for (let j = enemies.length - 1; j >= 0; j--) {
      const e = enemies[j];
      if (rectsOverlap(b, e)) {
        bullets.splice(i, 1);
        e.hp -= 1;
        spawnExplosion(b.x + b.width / 2, b.y, 'rgba(120,220,255,1)', 8);
        if (e.hp <= 0) {
          enemies.splice(j, 1);
          world.score += e.score;
          setSave({ score: world.score });
          updateHUD();
          spawnExplosion(e.x + e.width / 2, e.y + e.height / 2, 'rgba(255,200,120,1)', 24);
          // chance to drop powerup
          if (Math.random() < 0.18) {
            spawnPowerup(e.x + e.width / 2, e.y + e.height / 2);
          }
          unlockAchievement('firstBlood');
        }
        hit = true;
        break;
      }
    }
    if (hit) continue;
  }

  // Enemies -> Player
  const playerRect = { x: player.x, y: player.y, width: player.width, height: player.height };
  for (let j = enemies.length - 1; j >= 0; j--) {
    const e = enemies[j];
    if (rectsOverlap(playerRect, e)) {
      enemies.splice(j, 1);
      applyDamage(34);
      spawnExplosion(player.x + player.width / 2, player.y + player.height / 2, 'rgba(255,120,150,1)', 18);
    }
  }

  // Player -> Powerups
  for (let i = powerups.length - 1; i >= 0; i--) {
    const p = powerups[i];
    if (rectsOverlap(playerRect, p)) {
      powerups.splice(i, 1);
      applyPowerup(p.kind);
      spawnExplosion(player.x + player.width / 2, player.y + player.height / 2, 'rgba(120,220,255,1)', 10);
    }
  }
}

function applyDamage(amount) {
  if (player.hasShield) {
    player.shieldUntil = 0;
    player.hasShield = false;
    updateHUD();
    return;
  }
  player.health -= amount;
  if (player.health <= 0) {
    player.lives -= 1;
    if (player.lives <= 0) {
      updateHUD();
      gameOver();
      return;
    } else {
      player.health = player.maxHealth;
      resetPlayerPosition();
    }
  }
  updateHUD();
}

// ---------- Powerups ----------
// kinds: 'shield', 'double', 'speed', 'life'
function spawnPowerup(x, y) {
  const kinds = ['shield', 'double', 'speed', 'life'];
  const kind = kinds[Math.floor(Math.random() * kinds.length)];
  powerups.push({ x: x - 10, y: y - 10, width: 20, height: 20, vy: 80, kind });
}

function applyPowerup(kind) {
  const now = performance.now();
  if (kind === 'shield') {
    player.shieldUntil = now + 8000;
    player.hasShield = true;
  } else if (kind === 'double') {
    player.doubleFireUntil = Math.max(player.doubleFireUntil, now) + 8000;
  } else if (kind === 'speed') {
    player.speedBoostUntil = Math.max(player.speedBoostUntil, now) + 8000;
  } else if (kind === 'life') {
    player.lives += 1;
    updateHUD();
  }
}

function updatePowerups(dt) {
  const h = canvas.height / deviceScale;
  for (let i = powerups.length - 1; i >= 0; i--) {
    const p = powerups[i];
    p.y += p.vy * dt;
    if (p.y > h + 30) powerups.splice(i, 1);
  }
}

function drawPowerups() {
  for (const p of powerups) {
    let color = 'rgba(120,220,255,0.95)';
    if (p.kind === 'double') color = 'rgba(255,160,90,0.95)';
    else if (p.kind === 'speed') color = 'rgba(160,255,150,0.95)';
    else if (p.kind === 'life') color = 'rgba(255,90,140,0.95)';
    ctx.fillStyle = color;
    ctx.shadowColor = color.replace('0.95','0.5');
    ctx.shadowBlur = 10;
    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(p.x, p.y, p.width, p.height, 6);
    } else {
      // Fallback rounded rect
      const r = 6; const x = p.x, y = p.y, w = p.width, h = p.height;
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + w, y, x + w, y + h, r);
      ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r);
      ctx.arcTo(x, y, x + w, y, r);
      ctx.closePath();
    }
    ctx.fill();
    ctx.shadowBlur = 0;
    // icon
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    if (p.kind === 'shield') {
      ctx.beginPath();
      ctx.arc(p.x + 10, p.y + 12, 6, Math.PI, 0);
      ctx.lineTo(p.x + 16, p.y + 10);
      ctx.lineTo(p.x + 4, p.y + 10);
      ctx.closePath();
      ctx.fill();
    } else if (p.kind === 'double') {
      ctx.fillRect(p.x + 5, p.y + 6, 3, 8);
      ctx.fillRect(p.x + 12, p.y + 6, 3, 8);
    } else if (p.kind === 'speed') {
      ctx.beginPath();
      ctx.moveTo(p.x + 6, p.y + 8);
      ctx.lineTo(p.x + 14, p.y + 8);
      ctx.lineTo(p.x + 10, p.y + 14);
      ctx.closePath();
      ctx.fill();
    } else if (p.kind === 'life') {
      ctx.beginPath();
      ctx.moveTo(p.x + 10, p.y + 6);
      ctx.bezierCurveTo(p.x + 14, p.y + 2, p.x + 20, p.y + 8, p.x + 10, p.y + 18);
      ctx.bezierCurveTo(p.x, p.y + 8, p.x + 6, p.y + 2, p.x + 10, p.y + 6);
      ctx.fill();
    }
  }
}

// ---------- Background (parallax stars + soft clouds) ----------
const starLayers = [
  { stars: [], speed: 20, minR: 0.4, maxR: 1.0, color: 'rgba(180,200,255,0.45)', density: 1 / 22000 },
  { stars: [], speed: 45, minR: 0.6, maxR: 1.6, color: 'rgba(210,230,255,0.65)', density: 1 / 16000 },
  { stars: [], speed: 90, minR: 0.9, maxR: 2.0, color: 'rgba(230,241,255,0.95)', density: 1 / 12000 },
];

const clouds = [];

function rand(min, max) { return Math.random() * (max - min) + min; }

function initParallax() {
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;

  // Stars per layer
  for (const layer of starLayers) {
    layer.stars.length = 0;
    const count = Math.floor(w * h * layer.density);
    for (let i = 0; i < count; i++) {
      layer.stars.push({
        x: Math.random() * w,
        y: Math.random() * h,
        r: rand(layer.minR, layer.maxR),
      });
    }
  }

  // Soft cloud puffs
  clouds.length = 0;
  const cloudCount = Math.max(3, Math.floor(w / 380));
  for (let i = 0; i < cloudCount; i++) {
    clouds.push({
      x: Math.random() * w,
      y: Math.random() * (h * 0.7),
      w: rand(180, 360),
      h: rand(80, 160),
      speed: rand(8, 22),
      alpha: rand(0.06, 0.12),
      drift: rand(-8, 8),
    });
  }
}
initParallax();
window.addEventListener('resize', initParallax);

function drawBackground(dt) {
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;

  // Space gradient
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#0a0f2c');
  g.addColorStop(1, '#040714');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);

  // Far clouds (subtle)
  for (const c of clouds) {
    c.y += c.speed * dt;
    c.x += c.drift * dt * 0.25;
    if (c.y - c.h > h) {
      c.y = -c.h;
      c.x = Math.random() * w;
    }
    const grad = ctx.createRadialGradient(c.x + c.w * 0.4, c.y + c.h * 0.4, c.h * 0.2, c.x + c.w * 0.5, c.y + c.h * 0.5, c.h);
    grad.addColorStop(0, `rgba(200,220,255,${c.alpha})`);
    grad.addColorStop(1, 'rgba(200,220,255,0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, c.w, c.h, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Star layers parallax
  for (const layer of starLayers) {
    ctx.fillStyle = layer.color;
    for (const s of layer.stars) {
      s.y += layer.speed * dt;
      if (s.y > h + 3) {
        s.y = -3;
        s.x = Math.random() * w;
      }
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// ---------- Player Update/Draw ----------
function updatePlayer(dt, now) {
  const speed = player.speed * (now < player.speedBoostUntil ? 1.5 : 1);
  let ax = 0, ay = 0;

  if (keysDown.has('arrowleft') || keysDown.has('a')) ax -= 1;
  if (keysDown.has('arrowright') || keysDown.has('d')) ax += 1;
  if (keysDown.has('arrowup') || keysDown.has('w')) ay -= 1;
  if (keysDown.has('arrowdown') || keysDown.has('s')) ay += 1;

  // Touch drag moves toward finger
  if (isTouching && lastTouch) {
    const rect = canvas.getBoundingClientRect();
    const targetX = lastTouch.clientX - rect.left - player.width / 2;
    const targetY = lastTouch.clientY - rect.top - player.height / 2;
    const dx = targetX - player.x;
    const dy = targetY - player.y;
    const len = Math.hypot(dx, dy) || 1;
    ax = dx / len;
    ay = dy / len;
  }

  player.vx = ax * speed;
  player.vy = ay * speed;
  player.x += player.vx * dt;
  player.y += player.vy * dt;

  // Clamp to screen
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;
  player.x = Math.max(0, Math.min(w - player.width, player.x));
  player.y = Math.max(0, Math.min(h - player.height, player.y));

  // Auto-fire: keep firing while playing (tap still allowed on mobile)
  const shouldAutoFire = world.state === GameState.Playing;
  if (shouldAutoFire || shootRequested) {
    tryShoot(now);
    shootRequested = false;
  }

  // Shield timer
  player.hasShield = now < player.shieldUntil;
}

function drawPlayer() {
  const x = player.x;
  const y = player.y;
  const w = player.width;
  const h = player.height;

  // Slight tilt based on horizontal velocity
  const tilt = Math.max(-0.25, Math.min(0.25, player.vx / 600));
  ctx.save();
  ctx.translate(x + w / 2, y + h / 2);
  ctx.rotate(tilt);
  ctx.translate(-(x + w / 2), -(y + h / 2));

  // Hull body with layered glow
  const grad = ctx.createLinearGradient(x, y, x, y + h);
  grad.addColorStop(0, 'rgba(160,240,255,0.95)');
  grad.addColorStop(0.5, 'rgba(110,200,255,0.9)');
  grad.addColorStop(1, 'rgba(150,110,255,0.9)');
  ctx.fillStyle = grad;
  ctx.shadowColor = 'rgba(120,220,255,0.55)';
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.moveTo(x + w / 2, y);
  ctx.lineTo(x + w * 0.92, y + h * 0.7);
  ctx.lineTo(x + w * 0.68, y + h);
  ctx.lineTo(x + w * 0.32, y + h);
  ctx.lineTo(x + w * 0.08, y + h * 0.7);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;

  // Accents/stripes
  ctx.fillStyle = 'rgba(255,255,255,0.25)';
  ctx.fillRect(x + w * 0.25, y + h * 0.2, w * 0.5, 2);
  ctx.fillRect(x + w * 0.22, y + h * 0.45, w * 0.56, 2);

  // Cockpit canopy (glass)
  const canopy = ctx.createLinearGradient(x, y + h * 0.25, x, y + h * 0.55);
  canopy.addColorStop(0, 'rgba(255,255,255,0.9)');
  canopy.addColorStop(1, 'rgba(120,200,255,0.7)');
  ctx.fillStyle = canopy;
  ctx.beginPath();
  ctx.ellipse(x + w * 0.5, y + h * 0.42, w * 0.16, h * 0.12, 0, 0, Math.PI * 2);
  ctx.fill();

  // Wings glow
  ctx.fillStyle = 'rgba(120,220,255,0.2)';
  ctx.fillRect(x + w * 0.05, y + h * 0.62, w * 0.9, h * 0.06);

  // Thruster flames (animated, layered)
  const baseFlame = 14 + Math.random() * 10;
  const flameColors = ['rgba(255,220,120,0.95)', 'rgba(255,150,80,0.9)', 'rgba(255,90,60,0.85)'];
  const thrusters = [x + w * 0.3, x + w * 0.7];
  for (let i = 0; i < thrusters.length; i++) {
    const tx = thrusters[i];
    for (let k = 0; k < 3; k++) {
      ctx.fillStyle = flameColors[k];
      ctx.shadowColor = 'rgba(255,170,90,0.6)';
      ctx.shadowBlur = 16 - k * 4;
      ctx.beginPath();
      ctx.ellipse(tx, y + h, 5 - k, baseFlame - k * 4, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Shield visual
  if (player.hasShield) {
    ctx.strokeStyle = 'rgba(120,220,255,0.7)';
    ctx.lineWidth = 3;
    ctx.shadowColor = 'rgba(120,220,255,0.6)';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.ellipse(x + w / 2, y + h / 2, w * 0.65, h * 0.75, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.shadowBlur = 0;
  }

  ctx.restore();
}

// ---------- Main Loop ----------
let lastTime = performance.now();
function frame(now) {
  const dt = Math.min(0.033, (now - lastTime) / 1000);
  lastTime = now;

  if (world.state === GameState.Menu) {
    drawBackground(dt);
    // idle player preview
    drawTitleIdle(dt);
  } else if (world.state === GameState.Playing) {
    drawBackground(dt);
    updatePlayer(dt, now);
    updateWaves(dt);
    updateEnemies(dt);
    updateBullets(dt);
    updatePowerups(dt);
    updateParticles(dt);
    handleCollisions();
    drawBullets();
    drawEnemies();
    drawPowerups();
    drawParticles();
    drawPlayer();
  } else if (world.state === GameState.Paused) {
    drawBackground(dt);
    drawBullets();
    drawEnemies();
    drawPowerups();
    drawParticles();
    drawPlayer();
    drawPauseOverlay();
  } else if (world.state === GameState.GameOver) {
    drawBackground(dt);
  }

  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

function drawTitleIdle(dt) {
  world.bgTime += dt;
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;
  const px = w / 2 - player.width / 2;
  const py = h * 0.62 + Math.sin(world.bgTime * 2) * 8;
  // ghost player
  ctx.globalAlpha = 0.9;
  const origX = player.x, origY = player.y;
  player.x = px; player.y = py;
  drawPlayer();
  player.x = origX; player.y = origY;
  ctx.globalAlpha = 1;
}

function drawPauseOverlay() {
  const w = canvas.width / deviceScale;
  const h = canvas.height / deviceScale;
  ctx.fillStyle = 'rgba(4,7,20,0.45)';
  ctx.fillRect(0, 0, w, h);
}

// ---------- Achievements ----------
function unlockAchievement(key) {
  if (world.sessionAchievements[key]) return;
  world.sessionAchievements[key] = true;
  const saved = getAchievements();
  if (!saved[key]) {
    saved[key] = true;
    setAchievements(saved);
  }
}

function renderSessionAchievements() {
  const labels = {
    firstBlood: 'First Blood',
    level3: 'Climber: Level 3',
    level5: 'Ace: Level 5',
    survivor: 'Survivor (No death)',
    bossSlayer: 'Boss Slayer',
  };
  const keys = Object.keys(world.sessionAchievements).filter(k => world.sessionAchievements[k]);
  if (keys.length === 0) return '<div class="badge">No new achievements</div>';
  return keys.map(k => `<div class="badge">${labels[k] || k}</div>`).join('');
}

// ---------- Wire UI Buttons ----------
btnStart.addEventListener('click', startGame);
btnResume.addEventListener('click', () => {
  if (world.state === GameState.Paused) togglePause();
});
btnRestart.addEventListener('click', () => {
  resetGame();
  world.state = GameState.Playing;
  showMenu(null);
  showHUD(true);
});
btnPlayAgain.addEventListener('click', () => {
  resetGame();
  world.state = GameState.Playing;
  showMenu(null);
  showHUD(true);
});
btnHome.addEventListener('click', () => {
  world.state = GameState.Menu;
  showHUD(false);
  showMenu(menuStartEl);
  renderLeaderboard();
});

// Prefill name and leaderboard
playerNameInput.value = getPlayerName();
renderLeaderboard();
updateHUD();
resetPlayerPosition();


